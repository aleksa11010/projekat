package com.leontina_stosic.singidunum.biblioteka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotekaApplicationTests {

	@Test
	void contextLoads() {
	}

}
